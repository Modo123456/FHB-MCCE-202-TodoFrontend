export interface TodoItemOwner {
    name: string;
    email: string;
}

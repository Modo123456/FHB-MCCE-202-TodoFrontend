export enum TodoItemState {
    Open = 0,
    Doing = 1,
    Done = 2
}
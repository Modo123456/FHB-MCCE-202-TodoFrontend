export interface AwsConfig {
    region: string;
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken: string;
}